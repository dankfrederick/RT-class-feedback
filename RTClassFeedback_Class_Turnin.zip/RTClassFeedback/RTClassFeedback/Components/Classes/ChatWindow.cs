﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RTClassFeedback.Components.Classes
{
    class ChatWindow
    {
        //Implemenation of this object is not currently required, messaged maintained as an array of objects on MainPage
    }
}
